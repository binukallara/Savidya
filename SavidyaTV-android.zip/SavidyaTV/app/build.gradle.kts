import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "info.savidya.tv"
    compileSdk = 34
    defaultConfig {
        applicationId = "info.savidya.tv"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("io.coil-kt:coil:2.5.0")
}

// Savidya ലോഗോ ബിൽഡ് സമയത്ത് ഡൗൺലോഡ് ചെയ്ത് ആപ്പ് ഐക്കൺ ആക്കുന്നു (512 പരാജയപ്പെട്ടാൽ 192, അതും പരാജയപ്പെട്ടാൽ സാധാരണ ഐക്കൺ)
val fetchLogo by tasks.registering {
    val out = file("src/main/res/drawable-nodpi/ic_launcher.png")
    val urls = listOf(
        "https://raw.githubusercontent.com/binukallara/Savidya-tv/refs/heads/main/socialbu-resized-512x512.png",
        "https://raw.githubusercontent.com/binukallara/Savidya-tv/refs/heads/main/socialbu-resized-192x192.png"
    )
    doLast {
        val magic = listOf(0x89.toByte(), 0x50.toByte(), 0x4E.toByte(), 0x47.toByte())
        out.parentFile.mkdirs()
        var ok = false
        for (u in urls) {
            if (ok) break
            try {
                URL(u).openStream().use { input -> out.outputStream().use { o -> input.copyTo(o) } }
                ok = out.length() > 500 && out.readBytes().copyOf(4).toList() == magic
            } catch (e: Exception) {
                println("Logo download failed: " + u + " " + e)
            }
            if (!ok) out.delete()
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchLogo) }
