package info.savidya.tv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Ch(val id: String, val name: String, val logo: String, val url: String, val cat: String)

object Data {
    const val IP = "https://iptv-org.github.io/iptv/"

    val LANGS = listOf(
        "Malayalam" to "mal", "Tamil" to "tam", "Hindi" to "hin", "Telugu" to "tel",
        "Kannada" to "kan", "English" to "eng", "Bengali" to "ben", "Marathi" to "mar"
    )
    val CATS = listOf(
        Triple("🎬", "Entertainment", "general"), Triple("📰", "News", "news"),
        Triple("⚽", "Sports", "sports"), Triple("🍿", "Movies", "movies"),
        Triple("😄", "Comedy", "comedy"), Triple("🧒", "Kids", "kids"),
        Triple("🎵", "Music", "music"), Triple("🙏", "Devotional", "religious"),
        Triple("📺", "Series", "series"), Triple("🎓", "Education", "education")
    )
    val MAL = listOf(
        Triple("Stream 1", "Official IPTV Playlist", IP + "languages/mal.m3u"),
        Triple("Stream 2", "Backup Stream Server", "https://m3u.ch/b2VPvT.m3u")
    )
    private const val CT = "in|India|🇮🇳;us|United States|🇺🇸;gb|United Kingdom|🇬🇧;ca|Canada|🇨🇦;au|Australia|🇦🇺;de|Germany|🇩🇪;fr|France|🇫🇷;it|Italy|🇮🇹;es|Spain|🇪🇸;pt|Portugal|🇵🇹;nl|Netherlands|🇳🇱;be|Belgium|🇧🇪;ch|Switzerland|🇨🇭;at|Austria|🇦🇹;se|Sweden|🇸🇪;no|Norway|🇳🇴;dk|Denmark|🇩🇰;fi|Finland|🇫🇮;pl|Poland|🇵🇱;cz|Czechia|🇨🇿;ro|Romania|🇷🇴;gr|Greece|🇬🇷;tr|Turkey|🇹🇷;ru|Russia|🇷🇺;ua|Ukraine|🇺🇦;br|Brazil|🇧🇷;ar|Argentina|🇦🇷;mx|Mexico|🇲🇽;cl|Chile|🇨🇱;co|Colombia|🇨🇴;pe|Peru|🇵🇪;jp|Japan|🇯🇵;kr|South Korea|🇰🇷;cn|China|🇨🇳;tw|Taiwan|🇹🇼;hk|Hong Kong|🇭🇰;sg|Singapore|🇸🇬;my|Malaysia|🇲🇾;id|Indonesia|🇮🇩;ph|Philippines|🇵🇭;th|Thailand|🇹🇭;vn|Vietnam|🇻🇳;pk|Pakistan|🇵🇰;bd|Bangladesh|🇧🇩;lk|Sri Lanka|🇱🇰;np|Nepal|🇳🇵;ae|UAE|🇦🇪;sa|Saudi Arabia|🇸🇦;qa|Qatar|🇶🇦;kw|Kuwait|🇰🇼;om|Oman|🇴🇲;bh|Bahrain|🇧🇭;il|Israel|🇮🇱;eg|Egypt|🇪🇬;za|South Africa|🇿🇦;ng|Nigeria|🇳🇬;ke|Kenya|🇰🇪;gh|Ghana|🇬🇭;nz|New Zealand|🇳🇿"
    val COUNTRIES: List<Triple<String, String, String>> = CT.split(";").map { s ->
        val p = s.split("|")
        Triple(p[0], p[1], p[2])
    }

    fun hid(u: String): String = Integer.toHexString(u.hashCode())

    private val reName = Regex(",(.+)$")
    private val reLogo = Regex("tvg-logo=\"([^\"]+)\"")
    private val reGroup = Regex("group-title=\"([^\"]+)\"")

    fun parse(txt: String): List<Ch> {
        val out = ArrayList<Ch>()
        val seen = HashSet<String>()
        var name = ""
        var logo = ""
        var cat = ""
        var has = false
        for (raw in txt.lineSequence()) {
            val l = raw.trim()
            if (l.startsWith("#EXTINF:")) {
                has = true
                name = reName.find(l)?.groupValues?.get(1)?.trim() ?: "Unknown"
                logo = reLogo.find(l)?.groupValues?.get(1)?.trim() ?: ""
                cat = reGroup.find(l)?.groupValues?.get(1) ?: "General"
            } else if (l.isNotEmpty() && !l.startsWith("#") && has) {
                has = false
                val id = hid(l)
                if (logo.isNotEmpty() && seen.add(id)) out.add(Ch(id, name, logo, l, cat))
            }
        }
        return out
    }

    fun fetch(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 SavidyaTV")
        try {
            if (c.responseCode != 200) throw RuntimeException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sv", Context.MODE_PRIVATE)

    fun list(key: String): MutableList<Ch> {
        val out = ArrayList<Ch>()
        try {
            val a = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Ch(o.getString("id"), o.getString("n"), o.getString("l"), o.getString("u"), o.getString("c")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun save(key: String, l: List<Ch>) {
        val a = JSONArray()
        for (c in l) {
            a.put(JSONObject().put("id", c.id).put("n", c.name).put("l", c.logo).put("u", c.url).put("c", c.cat))
        }
        sp.edit().putString(key, a.toString()).apply()
    }

    var quality: String
        get() = sp.getString("q", "auto") ?: "auto"
        set(v) {
            sp.edit().putString("q", v).apply()
        }
}
