package info.savidya.tv

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Rational
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.AdaptiveTrackSelection
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import java.io.File

private val BG = 0xFF0A0C12.toInt()
private val SURF = 0xFF131622.toInt()
private val SURF2 = 0xFF1C2033.toInt()
private val ACCENT = 0xFF8B7CFF.toInt()
private val TX = 0xFFEEF0F8.toInt()
private val TX2 = 0xFF98A0BA.toInt()
private val OK = 0xFF3DDC97.toInt()
private val LOAD = 0xFFFFB86B.toInt()
private val BAD = 0xFFFF5A4F.toInt()

class MenuItem(val label: String, val isList: Boolean, val action: () -> Unit)

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var store: Store
    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var playerFrame: FrameLayout
    private lateinit var infoBar: LinearLayout
    private lateinit var listPane: LinearLayout
    private lateinit var menuRv: RecyclerView
    private lateinit var chanRv: RecyclerView
    private lateinit var spinner: ProgressBar
    private lateinit var osdTv: TextView
    private lateinit var nameTv: TextView
    private lateinit var catTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var countTv: TextView
    private lateinit var logoIv: ImageView
    private lateinit var chanAdapter: ChanAdapter
    private lateinit var menuAdapter: MenuAdapter

    private val ui = Handler(Looper.getMainLooper())
    private var allCh: List<Ch> = emptyList()
    private var shown: List<Ch> = emptyList()
    private var cur: Ch? = null
    private var listMode = "all"
    private var catFilter: String? = null
    private var query = ""
    private var menuSel = "🌐 Country: India"
    private var fullscreen = false
    private var inPip = false
    private var favs = mutableListOf<Ch>()
    private var recents = mutableListOf<Ch>()
    private var skips = 0
    private var retries = 0
    private var hlsForced = false
    private var capHeight = Int.MAX_VALUE
    private var numBuf = ""
    private var loadGen = 0
    private val menuItems = ArrayList<MenuItem>()

    private val isTv: Boolean
        get() = packageManager.hasSystemFeature("android.software.leanback") ||
                packageManager.hasSystemFeature("android.hardware.type.television")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        store = Store(this)
        favs = store.list("favs")
        recents = store.list("recents")
        buildUi()
        initPlayer()
        buildMenu()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (fullscreen) setFullscreen(false)
                else if (isTv && !playerFrame.isFocused) playerFrame.requestFocus()
                else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        loadList(Data.IP + "countries/in.m3u", true)
        playerFrame.post { playerFrame.requestFocus() }
    }

    override fun onStart() {
        super.onStart()
        if (cur != null) {
            player.seekToDefaultPosition()
            player.play()
        }
    }

    override fun onStop() {
        super.onStop()
        if (!inPip) player.pause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        player.release()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayout()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!isTv && player.isPlaying) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        applyLayout()
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        playerView = PlayerView(this).apply {
            useController = false
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            setShutterBackgroundColor(Color.BLACK)
        }
        spinner = ProgressBar(this).apply { visibility = View.GONE }
        osdTv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = box(0xCC0A0C14.toInt(), 0, 0, 12)
            visibility = View.GONE
        }
        playerFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isFocusable = true
            isClickable = true
            setOnClickListener { toggleFullscreen() }
            setOnFocusChangeListener { v, f ->
                (v as FrameLayout).foreground = if (f) GradientDrawable().apply {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(3), ACCENT)
                } else null
            }
            addView(playerView, FrameLayout.LayoutParams(-1, -1))
            addView(spinner, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))
            addView(osdTv, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(14), dp(14), 0, 0) })
        }
        logoIv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        nameTv = TextView(this).apply {
            setTextColor(TX); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; text = "ചാനൽ തിരഞ്ഞെടുക്കുക"
        }
        catTv = TextView(this).apply { setTextColor(TX2); textSize = 12f; maxLines = 1 }
        statusTv = TextView(this).apply {
            setTextColor(LOAD); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; text = "IDLE"
            setPadding(dp(10), dp(3), dp(10), dp(3))
            background = box(SURF2, 0, 0, 20)
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(nameTv)
            addView(catTv)
        }
        infoBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(SURF)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            addView(logoIv, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
            addView(statusTv)
        }
        menuAdapter = MenuAdapter()
        menuRv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = menuAdapter
            isFocusable = false
            clipToPadding = false
            setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        countTv = TextView(this).apply {
            setTextColor(TX2); textSize = 12f
            setPadding(dp(14), dp(2), dp(14), dp(2))
        }
        chanAdapter = ChanAdapter()
        chanRv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(context, cols())
            adapter = chanAdapter
            itemAnimator = null
            isFocusable = false
            clipToPadding = false
            setPadding(dp(8), dp(4), dp(8), dp(12))
        }
        listPane = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(menuRv, LinearLayout.LayoutParams(-1, -2))
            addView(countTv, LinearLayout.LayoutParams(-1, -2))
            addView(chanRv, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        root.addView(playerFrame, LinearLayout.LayoutParams(-1, dp(220)))
        root.addView(infoBar, LinearLayout.LayoutParams(-1, -2))
        root.addView(listPane, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        applyLayout()
    }

    private fun cols(): Int {
        val dm = resources.displayMetrics
        return maxOf(3, (dm.widthPixels / dm.density / 140f).toInt())
    }

    private fun applyLayout() {
        val dm = resources.displayMetrics
        val hide = fullscreen || inPip
        listPane.visibility = if (hide) View.GONE else View.VISIBLE
        infoBar.visibility = if (hide) View.GONE else View.VISIBLE
        val lp = playerFrame.layoutParams as LinearLayout.LayoutParams
        lp.height = if (hide) ViewGroup.LayoutParams.MATCH_PARENT
        else minOf(dm.widthPixels * 9 / 16, (dm.heightPixels * 0.46f).toInt())
        playerFrame.layoutParams = lp
        (chanRv.layoutManager as GridLayoutManager).spanCount = cols()
    }

    private fun box(fill: Int, stroke: Int, sw: Int, r: Int = 12) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
        if (sw > 0) setStroke(dp(sw), stroke)
    }

    private fun styleCard(v: View, focused: Boolean, active: Boolean) {
        v.background = when {
            focused -> box(SURF2, Color.WHITE, 3)
            active -> box(SURF, ACCENT, 2)
            else -> box(SURF, 0x22FFFFFF, 1)
        }
        val s = if (focused) 1.06f else 1f
        v.animate().scaleX(s).scaleY(s).setDuration(120).start()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private val hideOsd = Runnable { osdTv.visibility = View.GONE }
    private fun osd(t: String) {
        osdTv.text = t
        osdTv.visibility = View.VISIBLE
        ui.removeCallbacks(hideOsd)
        ui.postDelayed(hideOsd, 3500)
    }

    private fun setStatus(t: String, c: Int) {
        statusTv.text = t
        statusTv.setTextColor(c)
    }

    // ---------- adapters ----------
    inner class MenuAdapter : RecyclerView.Adapter<MenuAdapter.VH>() {
        inner class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val tv = TextView(this@MainActivity).apply {
                setTextColor(TX); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(16), dp(9), dp(16), dp(9)); isFocusable = true
                layoutParams = RecyclerView.LayoutParams(-2, -2).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            }
            return VH(tv)
        }

        override fun getItemCount() = menuItems.size

        override fun onBindViewHolder(h: VH, i: Int) {
            val m = menuItems[i]
            h.tv.text = m.label
            val sel = (m.isList && m.label == menuSel) || (m.label.contains("Fav") && listMode == "fav") ||
                    (m.label.contains("Recent") && listMode == "rec")
            fun paint(f: Boolean) {
                h.tv.background = when {
                    f -> box(SURF2, Color.WHITE, 3, 24)
                    sel -> box(ACCENT, 0, 0, 24)
                    else -> box(SURF, 0x22FFFFFF, 1, 24)
                }
                val s = if (f) 1.07f else 1f
                h.tv.animate().scaleX(s).scaleY(s).setDuration(120).start()
            }
            paint(false)
            h.tv.setOnFocusChangeListener { _, f -> paint(f) }
            h.tv.setOnClickListener { m.action() }
        }
    }

    inner class ChanAdapter : RecyclerView.Adapter<ChanAdapter.VH>() {
        inner class VH(val box: LinearLayout, val img: ImageView, val name: TextView, val cat: TextView) : RecyclerView.ViewHolder(box)

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(6), dp(10), dp(6), dp(8)); isFocusable = true
                layoutParams = RecyclerView.LayoutParams(-1, dp(122)).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) }
            }
            val img = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            val name = TextView(this@MainActivity).apply {
                setTextColor(TX); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            }
            val cat = TextView(this@MainActivity).apply {
                setTextColor(TX2); textSize = 10f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            }
            box.addView(img, LinearLayout.LayoutParams(dp(56), dp(56)))
            box.addView(name, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            box.addView(cat, LinearLayout.LayoutParams(-1, -2))
            box.setOnFocusChangeListener { v, f -> styleCard(v, f, v.tag == cur?.id) }
            return VH(box, img, name, cat)
        }

        override fun getItemCount() = shown.size

        override fun onBindViewHolder(h: VH, i: Int) {
            val c = shown[i]
            h.box.tag = c.id
            h.name.text = (if (isFav(c)) "♥ " else "") + c.name
            h.cat.text = c.cat
            h.img.load(c.logo)
            styleCard(h.box, h.box.hasFocus(), cur?.id == c.id)
            h.box.setOnClickListener { onChannelClick(c) }
            h.box.setOnLongClickListener { toggleFav(c); true }
        }
    }

    // ---------- menu ----------
    private fun buildMenu() {
        menuItems.add(MenuItem("🔎 തിരയുക", false) { searchDialog() })
        menuItems.add(MenuItem("❤️ Fav", false) { setMode("fav") })
        menuItems.add(MenuItem("🕐 Recent", false) { setMode("rec") })
        menuItems.add(MenuItem("🌐 Country", false) { countryDialog() })
        menuItems.add(MenuItem("📂 വിഭാഗം", false) { categoryDialog() })
        menuItems.add(MenuItem("📶 Quality", false) { qualityDialog() })
        menuItems.add(MenuItem("🖼 PiP", false) { enterPip() })
        for ((n, c) in Data.LANGS) {
            val label = "🌐 $n"
            menuItems.add(MenuItem(label, true) {
                if (c == "mal") malDialog() else selectList(label, Data.IP + "languages/$c.m3u")
            })
        }
        for ((e, n, c) in Data.CATS) {
            val label = "$e $n"
            menuItems.add(MenuItem(label, true) { selectList(label, Data.IP + "categories/$c.m3u") })
        }
        menuAdapter.notifyDataSetChanged()
    }

    private fun selectList(label: String, url: String) {
        menuSel = label
        loadList(url, true)
    }

    private fun setMode(m: String) {
        val next = if (listMode == m) "all" else m
        if (next == "fav" && favs.isEmpty()) { toast("Favorites ഒന്നും ഇല്ല"); return }
        if (next == "rec" && recents.isEmpty()) { toast("ഇതുവരെ ഒന്നും കണ്ടിട്ടില്ല"); return }
        listMode = next
        filter()
        menuAdapter.notifyDataSetChanged()
    }

    private fun malDialog() {
        val names = Data.MAL.map { it.first + " · " + it.second }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Malayalam Streams").setItems(names) { _, i ->
            selectList("🌐 Malayalam", Data.MAL[i].third)
        }.show()
    }

    private fun countryDialog() {
        val names = Data.COUNTRIES.map { it.third + " " + it.second }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Country").setItems(names) { _, i ->
            val c = Data.COUNTRIES[i]
            selectList("🌐 Country: " + c.second, Data.IP + "countries/" + c.first + ".m3u")
        }.show()
    }

    private fun categoryDialog() {
        val cats = allCh.map { it.cat }.distinct().sorted()
        val names = (listOf("എല്ലാ വിഭാഗവും") + cats).toTypedArray()
        AlertDialog.Builder(this).setTitle("വിഭാഗം").setItems(names) { _, i ->
            catFilter = if (i == 0) null else cats[i - 1]
            filter()
        }.show()
    }

    private fun qualityDialog() {
        val names = arrayOf("Auto (വേഗതയ്ക്ക് അനുസരിച്ച്)", "💧 Data saver (360p)", "480p", "720p", "1080p")
        val vals = arrayOf("auto", "saver", "480", "720", "1080")
        AlertDialog.Builder(this).setTitle("Quality").setItems(names) { _, i ->
            store.quality = vals[i]
            capHeight = Int.MAX_VALUE
            applyQuality()
            toast("Quality: " + names[i])
        }.show()
    }

    private fun searchDialog() {
        val et = EditText(this).apply {
            setText(query); hint = "ചാനൽ പേര്"; setSingleLine()
        }
        AlertDialog.Builder(this).setTitle("തിരയുക").setView(et)
            .setPositiveButton("OK") { _, _ -> query = et.text.toString().trim(); filter() }
            .setNegativeButton("Clear") { _, _ -> query = ""; filter() }
            .show()
    }

    // ---------- playlist ----------
    private fun loadList(url: String, auto: Boolean) {
        listMode = "all"
        catFilter = null
        query = ""
        val gen = ++loadGen
        val f = File(cacheDir, "pl_" + Data.hid(url))
        var cached = false
        if (f.exists()) {
            try {
                val l = Data.parse(f.readText())
                if (l.isNotEmpty()) {
                    cached = true
                    setChannels(l, auto)
                }
            } catch (e: Exception) {
            }
        }
        if (!cached) {
            allCh = emptyList()
            filter()
            countTv.text = "⏳ ചാനലുകൾ ലോഡ് ചെയ്യുന്നു…"
        }
        val hadCache = cached
        Thread {
            try {
                val txt = Data.fetch(url)
                val l = Data.parse(txt)
                if (l.isEmpty()) throw RuntimeException("empty")
                f.writeText(txt)
                runOnUiThread {
                    if (gen == loadGen && !isDestroyed) {
                        if (!hadCache) setChannels(l, auto)
                        else if (l.size != allCh.size) { allCh = l; filter() }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (!hadCache && gen == loadGen && !isDestroyed)
                        countTv.text = "❌ ലോഡ് ചെയ്യാൻ കഴിഞ്ഞില്ല — നെറ്റ്‌വർക്ക് നോക്കി വീണ്ടും ശ്രമിക്കുക"
                }
            }
        }.start()
        menuAdapter.notifyDataSetChanged()
    }

    private fun setChannels(l: List<Ch>, auto: Boolean) {
        allCh = l
        filter()
        if (auto && l.isNotEmpty()) play(l[0])
    }

    private fun filter() {
        val base = when (listMode) { "fav" -> favs; "rec" -> recents; else -> allCh }
        shown = base.filter {
            (query.isEmpty() || it.name.contains(query, true)) && (catFilter == null || it.cat == catFilter)
        }
        countTv.text = "${shown.size} ചാനലുകൾ" + (if (listMode == "fav") " · ❤️ Favorites" else if (listMode == "rec") " · 🕐 Recent" else "")
        chanAdapter.notifyDataSetChanged()
    }

    private fun isFav(c: Ch) = favs.any { it.id == c.id }

    private fun toggleFav(c: Ch) {
        val i = favs.indexOfFirst { it.id == c.id }
        if (i >= 0) { favs.removeAt(i); toast("Favorites ൽ നിന്ന് നീക്കി") }
        else { favs.add(c); toast("Favorites ൽ ചേർത്തു") }
        store.save("favs", favs)
        if (listMode == "fav") filter() else refreshItem(c)
    }

    private fun refreshItem(c: Ch?) {
        if (c == null) return
        val i = shown.indexOfFirst { it.id == c.id }
        if (i >= 0) chanAdapter.notifyItemChanged(i)
    }

    private fun addRecent(c: Ch) {
        recents.removeAll { it.id == c.id }
        recents.add(0, c)
        while (recents.size > 12) recents.removeAt(recents.size - 1)
        store.save("recents", recents)
    }

    // ---------- player ----------
    private fun initPlayer() {
        val bw = DefaultBandwidthMeter.Builder(this).setInitialBitrateEstimate(600_000L).build()
        val ts = DefaultTrackSelector(this, AdaptiveTrackSelection.Factory(15000, 10000, 25000, 0.7f))
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android) SavidyaTV")
            .setConnectTimeoutMs(12000)
            .setReadTimeoutMs(20000)
            .setAllowCrossProtocolRedirects(true)
        val msf = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http))
            .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(6))
        val lc = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30000, 90000, 2500, 6000)
            .build()
        player = ExoPlayer.Builder(this)
            .setTrackSelector(ts)
            .setMediaSourceFactory(msf)
            .setLoadControl(lc)
            .setBandwidthMeter(bw)
            .build()
        player.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
        )
        player.playWhenReady = true
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> {
                        spinner.visibility = View.VISIBLE
                        setStatus("BUFFERING", LOAD)
                        ui.removeCallbacks(stallRun)
                        ui.postDelayed(stallRun, 6000)
                    }
                    Player.STATE_READY -> {
                        spinner.visibility = View.GONE
                        setStatus("LIVE", OK)
                        ui.removeCallbacks(stallRun)
                        skips = 0
                        retries = 0
                    }
                    else -> {}
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (!isPlaying && player.playbackState == Player.STATE_READY) setStatus("PAUSED", BAD)
                else if (isPlaying) setStatus("LIVE", OK)
            }

            override fun onPlayerError(error: PlaybackException) {
                handleError(error)
            }
        })
    }

    private val stallRun = object : Runnable {
        override fun run() {
            if (store.quality == "auto") {
                val next = if (capHeight > 480) 480 else if (capHeight > 360) 360 else 240
                if (next < capHeight) {
                    capHeight = next
                    applyQuality()
                    toast("📶 വേഗത കുറവ് — ക്വാളിറ്റി കുറച്ചു")
                }
            }
            ui.postDelayed(this, 8000)
        }
    }

    private fun applyQuality() {
        val q = store.quality
        var h = when (q) { "saver" -> 360; "480" -> 480; "720" -> 720; "1080" -> 1080; else -> Int.MAX_VALUE }
        if (q == "auto") h = minOf(h, capHeight)
        val br = if (q == "saver") 900_000 else Int.MAX_VALUE
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setMaxVideoSize(Int.MAX_VALUE, h)
            .setMaxVideoBitrate(br)
            .build()
    }

    private fun setItem(ch: Ch) {
        val b = MediaItem.Builder().setUri(ch.url)
        if (hlsForced) b.setMimeType(MimeTypes.APPLICATION_M3U8)
        b.setLiveConfiguration(
            MediaItem.LiveConfiguration.Builder()
                .setTargetOffsetMs(12000)
                .setMinPlaybackSpeed(0.97f)
                .setMaxPlaybackSpeed(1.03f)
                .build()
        )
        player.setMediaItem(b.build())
        applyQuality()
        player.prepare()
        player.play()
    }

    private fun play(ch: Ch) {
        val old = cur
        cur = ch
        retries = 0
        capHeight = Int.MAX_VALUE
        hlsForced = ch.url.contains("m3u8", true)
        nameTv.text = ch.name
        catTv.text = ch.cat
        logoIv.load(ch.logo)
        spinner.visibility = View.VISIBLE
        setStatus("LOADING", LOAD)
        setItem(ch)
        addRecent(ch)
        refreshItem(old)
        refreshItem(ch)
    }

    private fun handleError(e: PlaybackException) {
        if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            player.seekToDefaultPosition()
            player.prepare()
            return
        }
        val ch = cur ?: return
        if (!hlsForced && retries == 0) {
            hlsForced = true
            setItem(ch)
            return
        }
        if (retries < 3) {
            retries++
            ui.postDelayed({ if (cur === ch) player.prepare() }, 1200L * retries)
            return
        }
        if (skips < 4) {
            skips++
            toast("ഈ ചാനൽ പ്ലേ ആകുന്നില്ല — അടുത്തതിലേക്ക്")
            step(1)
        } else {
            spinner.visibility = View.GONE
            setStatus("ERROR", BAD)
            osd("ചാനൽ ലഭ്യമല്ല — Next / Previous അമർത്തുക")
        }
    }

    private fun onChannelClick(c: Ch) {
        if (cur?.id == c.id) toggleFullscreen()
        else {
            play(c)
            playerFrame.requestFocus()
        }
    }

    private fun step(d: Int) {
        if (shown.isEmpty()) return
        val i = shown.indexOfFirst { it.id == cur?.id }
        val n = if (i < 0) 0 else (i + d + shown.size) % shown.size
        play(shown[n])
        osd("${n + 1} / ${shown.size}   ${shown[n].name}")
        if (!fullscreen) chanRv.scrollToPosition(n)
    }

    private val digitRun = Runnable {
        val n = numBuf.toIntOrNull() ?: 0
        numBuf = ""
        if (n >= 1 && n <= shown.size) {
            play(shown[n - 1])
            osd("$n / ${shown.size}   ${shown[n - 1].name}")
            if (!fullscreen) chanRv.scrollToPosition(n - 1)
        } else osd("ചാനൽ $n ഇല്ല")
    }

    private fun digit(d: Int) {
        numBuf = if (numBuf.length >= 4) d.toString() else numBuf + d
        osd("📺 $numBuf")
        ui.removeCallbacks(digitRun)
        ui.postDelayed(digitRun, 1400)
    }

    private fun toggleFullscreen() = setFullscreen(!fullscreen)

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        applyLayout()
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (on) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
        if (!isTv) requestedOrientation =
            if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (on) playerFrame.requestFocus()
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26 && packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
            } catch (e: Exception) {
                toast("PiP ലഭ്യമല്ല")
            }
        } else toast("PiP ലഭ്യമല്ല")
    }

    // ---------- remote ----------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val k = e.keyCode
            when (k) {
                KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_NEXT,
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_PAGE_UP -> { step(1); return true }
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS,
                KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_PAGE_DOWN -> { step(-1); return true }
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY,
                KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                    if (player.isPlaying) player.pause() else player.play()
                    return true
                }
                KeyEvent.KEYCODE_PROG_RED -> { cur?.let { toggleFav(it) }; return true }
                KeyEvent.KEYCODE_PROG_GREEN -> { toggleFullscreen(); return true }
                KeyEvent.KEYCODE_PROG_BLUE -> { searchDialog(); return true }
            }
            if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9 && currentFocus !is EditText) {
                digit(k - KeyEvent.KEYCODE_0)
                return true
            }
            if (fullscreen && !inPip) {
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                when (k) {
                    KeyEvent.KEYCODE_DPAD_UP -> { step(1); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { step(-1); return true }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        cur?.let { osd(it.name + "  ·  " + it.cat) }
                        return true
                    }
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }
}
